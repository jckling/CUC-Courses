#include <bits/stdc++.h>
using namespace std;
const int maxn = 500005, mod = 1e9 + 7;
int mi[maxn];
inline int quick(int a, int b) {
	int res = a, ans = 1;
	for (int i = 0; i < 31; i ++) {
		if (1 << i & b) ans = (long long)ans * res % mod;
		res = (long long)res * res % mod;
	}
	return ans;
}
int C(int n, int m) {
	int tmp = (long long)mi[n - m] * mi[m] % mod;
	int ans = (long long)mi[n] * quick(tmp, mod - 2) % mod;
	return ans;
}
int main() {
	int n, m;
	mi[0] = 1;
	for (int i = 1; i <= 200000; i ++) mi[i] = (long long)mi[i - 1] * i % mod;
	int t;
	scanf("%d",&t);
	while (t--) {
		scanf("%d%d", &m, &n);
		printf("%d\n", (C(n + m - 1, m) - C(n + m - 1, m - 1) + mod) % mod);
	}
	return 0;
}
