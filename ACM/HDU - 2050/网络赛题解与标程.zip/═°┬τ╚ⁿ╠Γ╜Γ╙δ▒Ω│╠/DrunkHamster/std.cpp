#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
LL X,Y;
int T,n;
int dx[]={1,0,-1,0};
int dy[]={0,-1,0,1};
int main(){
#ifdef WK
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	scanf("%d",&T);
	int tt=0;
	while(T--){
		scanf("%d",&n);
		X=0;Y=0;
		for(int i=0;i<n;i++){
			int tmp;
			scanf("%d",&tmp);
			X += dx[i%4]*tmp;
			Y += dy[i%4]*tmp;
		}
		printf("Case #%d:%lld\n",++tt,X*X+Y*Y);
	}
	return 0;
}
