#include <bits/stdc++.h>
using namespace std;
int w[]={
2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7,7,7,7,8,8,8,9,9,9,9
};
int T,n;
int main(){
#ifdef WK
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif
	scanf("%d",&T);
	int tt=0;
	while(T--){
		string num;
		cin>>num;
		int m=num.length();
		printf("Case #%d:\n",++tt);
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			string s;
			cin>>s;
			int flag=0;
			for(int j=0;j<m;j++){
				if(w[s[j]-'a']!=num[j]-'0'){
					flag=1;break;
				}
			}
			if(flag)printf("How could that be possible?\n");
			else printf("Maybe..\n");
		}
	}
	return 0;
}
