#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
using namespace std;

#define eps 1e-6
#define INF 1e5

int rd() {
	int f = 1, x = 0;
	char ch = getchar();
	while (ch<'0' || ch>'9') { if (ch == '-')f = -1; ch = getchar(); }
	while (ch >= '0'&&ch <= '9') { x = x * 10 + ch - '0'; ch = getchar(); }
	return x * f;
}

int sgn(double x) {
	if (fabs(x) < eps) return 0;
	else if (x < 0)return -1;
	return 1;
}
struct point {
	double x, y;
	point(double _x, double _y) :x(_x), y(_y){}
	point(){}
	void input() {
		x = rd(), y = rd();
	}
	point operator + (const point &b) const {
		return point(x + b.x, y + b.y);
	}
	point operator - (const point &b) const {
		return point(x - b.x, y - b.y);
	}
	double operator * (const point &b) const {
		return x * b.x + y * b.y;
	}
	double operator ^ (const point &b) const {
		return x * b.y - y * b.x;
	}
	double len() {
		return hypot(x, y);
	}
	double distance(point p) {
		return hypot(x - p.x, y - p.y);
	}
};

struct line {
	point s, e;
	line(){}
	line(point _s, point _e) :s(_s), e(_e){}
	void input() {
		s.input(), e.input();
	}
	double length() {
		return s.distance(e);
	}
	double dispointtoline(point p) {
		return fabs((p - s) ^ (e - s)) / length();
	}
	double dispointtoseg(point p) {
		if (sgn((p - s)*(e - s)) < 0 || sgn((p - e)*(s - e) < 0))
			return min(p.distance(s),p.distance(e));
		return dispointtoline(p);
	}
};

struct node {
	double a;
	int c;
	node(double _a, int _c) :a(_a), c(_c) {}
};
bool cmp(node a, node b) {
	if (sgn(a.a - b.a) != 0) return a.a < b.a;
	else return a.c > b.c;
}
#define MAXN 2020
line l[MAXN];
double L;
int n;

double bin1(int i, double left, double right, double R) {
	while (right - left >= eps) {
		double mid = (left + right) / 2.0;
		if (l[i].dispointtoseg(point(mid, 0)) <= R)
			right = mid - eps;
		else left = mid + eps;
	}
	return left;
}

double bin2(int i, double left, double right, double R) {
	while (right - left >= eps) {
		double mid = (left + right) / 2.0;
		if (l[i].dispointtoseg(point(mid, 0)) <= R)
			left = mid + eps;
		else right = mid - eps;
	}
	return left;
}

double get(int i,double L) {
	double left = 0, right = L;
	while (right - left >= eps) {
		double mid = (left + right) / 2.0;
		double midmid = (right + mid) / 2.0;
		if (l[i].dispointtoseg(point(mid, 0)) < l[i].dispointtoseg(point(midmid, 0)))
			right = midmid - eps;
		else left = mid + eps;
	}
	return left;
}
bool check(double r) {
	vector<node> vec;
	for (int i = 0; i < n; i++) {
		double tmp = get(i, L);
		if (sgn(l[i].dispointtoseg(point(tmp, 0)) - r) >= 0) {
			vec.push_back(node(0, 1));
			vec.push_back(node(L, -1));
			continue;
		}
		if (sgn(l[i].dispointtoseg(point(0, 0)) - r) >= 0) {
			double tt = bin1(i, 0, tmp, r);
			vec.push_back(node(0, 1));
			vec.push_back(node(tt, -1));
		}
		if (sgn(l[i].dispointtoseg(point(L, 0)) - r) >= 0) {
			double tt = bin2(i, tmp, L, r);
			vec.push_back(node(tt, 1));
			vec.push_back(node(L, -1));
		}
	}
	sort(vec.begin(), vec.end(), cmp);
	int cnt = 0;
	for (unsigned int i = 0; i < vec.size(); i++) {
		cnt += vec[i].c;
		if (cnt >= n) return true;
	}
	return false;
}

double solve() {
	double l = 0, r = INF;
	while (r - l >= eps) {
		double mid = (l + r) / 2.0;
		if (check(mid)) l = mid + eps;
		else r = mid - eps;
	}
	return l;
}
int main() {
	freopen("data.in", "r", stdin);
	freopen("data.out", "w", stdout);
	int T; scanf("%d", &T);
	while (T--) {
		scanf("%d%lf", &n, &L);
		for (int i = 0; i < n; i++)
			l[i].input();
		printf("%.3lf\n", solve());
	}
	return 0;
}