#include <bits/stdc++.h>
using namespace std;
const int M = 1000100;
struct node
{
	int to,next;
}edge[M];
int n,m;
int p[M],num,size1;
int root[M],a[M],ls[M*10],rs[M*10],sum[M*10];
int fa[M/10][21],level[M/10];
void add(int x,int y)
{
	num++;
	edge[num].to=y;
	edge[num].next=p[x];
	p[x]=num;
}
void insert(int l,int r,int x,int &y,int s)
{
	y=++size1;
	sum[y]=sum[x]+1;
	if(l==r)
		return ;
	int mid=l+r>>1;
	ls[y]=ls[x],rs[y]=rs[x];
	if(s<=mid)
		insert(l,mid,ls[x],ls[y],s); 
	else
		insert(mid+1,r,rs[x],rs[y],s);
}
int query(int l,int r,int x,int y,int z,int v,int k)
{
	if(l==r)
		return l;
	int mid=l+r>>1;
	if(sum[ls[y]]+sum[ls[x]]-sum[ls[z]]-sum[ls[v]]>=k)
		return query(l,mid,ls[x],ls[y],ls[z],ls[v],k);
	return query(mid+1,r,rs[x],rs[y],rs[z],rs[v],k-(sum[ls[y]]+sum[ls[x]]-sum[ls[z]]-sum[ls[v]]));
}
void dfs(int x,int y)
{
	insert(1,100000,root[y],root[x],a[x]);
	level[x]=level[y]+1;
	fa[x][0]=y;
	for(int i=1;i<=20;i++)
		fa[x][i]=fa[fa[x][i-1]][i-1];
	for(int i=p[x];i!=0;i=edge[i].next)
	{
		int v=edge[i].to;
		if(v!=y)
			dfs(v,x);
	}
}
int get_lca(int x,int y)
{
	if(level[x]<level[y])
		swap(x,y);
	int s=level[x]-level[y];
	for(int i=20;i>=0;i--)
		if(s&(1<<i))
			x=fa[x][i];
	if(x==y)
		return x;
	for(int i=20;i>=0;i--)
		if(fa[x][i]!=fa[y][i])
		{
			x=fa[x][i];
			y=fa[y][i];
		}
	return fa[x][0];
}
int main()
{
	freopen("std.in","r",stdin);
	freopen("3.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&m);
		num=0;
		memset(p,0,sizeof(p));
		size1=0;
		memset(root,0,sizeof(root));
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		for(int i=1;i<n;i++)
		{
			int x,y;
			scanf("%d%d",&x,&y);
			add(x,y);
			add(y,x);
		}
		dfs(1,0);
		for(int i=1;i<=m;i++)
		{
			int x,y,k;
			scanf("%d%d%d",&x,&y,&k);
			int z=get_lca(x,y);
			int ss=level[x]+level[y]-2*level[z]-k+2;
			if(ss<=0)
				printf("-1\n");
			else
				printf("%d\n",query(1,100000,root[x],root[y],root[z],root[fa[z][0]],ss));
		}
	}
	return 0;
}
