#include <bits/stdc++.h>

#define lson rt<<1, l, mid
#define rson rt<<1|1, mid+1, r

using namespace std;

const int N = 200000 + 5;
const int INF = 0x7fffffff;

int n, q;
int val[N<<2];
void pushup(int rt) {
	val[rt] = min(val[rt<<1], val[rt<<1|1]);
}
void update(int rt, int l, int r, int p, int v) {
	if (l == r) {
		val[rt] = v;
		return;
	}
	int mid = (l + r) >> 1;
	if (p <= mid) update(lson, p, v);
	if (p >  mid) update(rson, p, v);
	pushup(rt);
}
int query(int rt, int l, int r, int ql, int qr) {
	if (ql <= l && r <= qr) {
		return val[rt];
	}
	int mid = (l + r) >> 1;
	int ret = INF;
	if (ql <= mid) ret = min(ret, query(lson, ql, qr));
	if (qr >  mid) ret = min(ret, query(rson, ql, qr));
	return ret;
}
int find(int l, int r, int lim) {
	int ans = -1;
	
	while (l <= r) {
		// cout << l << " " << r << endl;
		int mid = (l + r) >> 1;
		if (query(1, 1, n, l, mid) <= lim) {
			r = mid - 1;
			ans = mid;
		} else l = mid + 1;
	}
	return ans;
}

int main() {
	freopen("sample.in", "r", stdin);
	freopen("sample.out", "w", stdout);
	
	scanf("%d%d", &n, &q);
	char op[3];
	int x, y;
	memset(val, 0x7f, sizeof val);
	for (int i = 1; i <= q; ++i) {
		scanf("%s%d%d", op, &x, &y);
		if (op[0] == 'M') update(1, 1, n, y, x);
		if (op[0] == 'D') {
			printf("%d\n", find(y, n, x));
		}
	}
	return 0;
}